public class Exo1 {

        /*  EXERCICE 1 : Créer un algo qui définit si la valeur A est supérier ou égale à B */


    public static void main(String[] args) throws Exception {



        /* Déclaration des variables A et B  */


        int a = 0;

        int b = 1;



                /* On compare les valeurs de A et B  */

        if(a >= b){


                            /* Si A est supérieur ou égale à B  */


                    /* Afficher le résultat */
        System.out.println("A est supérieur ou égale à B");


        }else{

                                        /* B est inférieur à A  */

                    /* Afficher le résultat */
                    System.out.println("B est inférieur à A");


        }




    }
}
