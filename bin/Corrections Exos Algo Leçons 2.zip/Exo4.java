public class Exo4 {

    /*  EXERCICE 4 : Faire le compte à rebour à partir de 10, affichez successivment décompte, une fois à 0 affichez bonne année ! */

    public static void main(String[] args) throws Exception {

                            /* Démarrage du compteur à partir de 10 jusqu'à 0 , il s'agit d'un compteur décroissant */

        for(int i=10; i>=0;i--){


                            /* On vérifie si le compte est à 0 */
        if(i==0){

            /* Si le compteur est à 0, afficher bonne année */


                    /* Afficher le résultat */
        System.out.println("Bonne année !!!");
        }else{


                        /* Sinon afficher le nombre du compteur */

            System.out.println(i);

        }

        }

        
        
        }
        

}
